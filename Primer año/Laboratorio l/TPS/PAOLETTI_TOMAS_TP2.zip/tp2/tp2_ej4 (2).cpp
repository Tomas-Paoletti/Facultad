/*
4.	Escribir un programa que escriba todos los m�ltiplos de 3 del n�mero 1 al 3000
*/

#include  <iostream>
using namespace std;

 int main(){
int i;
i=0;
    for(i=3; i>=3000 i=i+3)
    {
        cout<<i<<endl;
    }
    
 }
 
